import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {
  userForm:FormGroup
  constructor(private userService:UserService,private router:Router) {
    this.userForm = new FormGroup({
      'userID': new FormControl('', Validators.required),
      'date': new FormControl('', [Validators.required]),
      'status': new FormControl('', Validators.required),
    })
  }

  ngOnInit(): void {

  }

  submitUser(){
    Object.keys(this.userForm.controls).forEach(field => {
      const control = this.userForm.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      }
    });

    if(this.userForm.valid){
      console.log(this.userForm.value);
      this.userService.saveUser(this.userForm.value).subscribe(() => {
        this.router.navigate(['/user-list'])
      },() => {
        alert("Something Went Wrong")
      })
      
    }
  }

}