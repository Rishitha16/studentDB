export interface User {
    id?:number,
    userName: string,
    userEmail: string,
    phoneNumber: string,
    country: string
}